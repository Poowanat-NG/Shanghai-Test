window.TRIP_MAP_CONFIG = Object.freeze({
  // Paste the Apps Script Web App URL that ends in /exec.
  dataApiUrl: "PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE"
});
